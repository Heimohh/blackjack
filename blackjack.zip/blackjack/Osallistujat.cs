﻿using blackjack;

public class Participant
{
    public List<Card> Hand { get; } = new List<Card>();

    public void TakeCard(Card card)
    {
        Hand.Add(card);
    }

    public int GetHandValue()
    {
        int total = 0;

        foreach (var card in Hand)
        {
            total += card.Value;
        }

        return total;
    }
}

public class Player : Participant
{
    public int Money { get; set; } = 100;

    public void ShowHand()
    {
        Console.WriteLine("Player cards:");

        foreach (var card in Hand)
        {
            Console.WriteLine(card);
        }
    }
}

public class Dealer : Participant
{
    public void PlayTurn(Deck deck)
    {
        while (GetHandValue() < 17)
        {
            TakeCard(deck.Draw());
        }
    }
}