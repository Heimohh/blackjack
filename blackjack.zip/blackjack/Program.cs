﻿using System;

namespace blackjack
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Deck deck = new Deck();
            Player player = new Player();

            Console.WriteLine($"Kortteja pakassa: {deck.CardsRemaining}");
            player.TakeCard(deck.Draw());
            player.TakeCard(deck.Draw());
            player.ShowHand();
            Console.WriteLine(player.GetHandValue());
            

            Console.WriteLine($"Kortteja jäljellä: {deck.CardsRemaining}");
        }
    }
}